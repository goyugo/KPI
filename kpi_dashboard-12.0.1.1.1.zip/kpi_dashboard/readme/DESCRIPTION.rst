This module adds new kinds of dashboards on a specific new type of view.
