* Daniel Reis <dreis.pt@hotmail.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Dave Lasley <dave@laslabs.com>
* Sergio Teruel <sergio.teruel@tecnativa.com> (https://wwww.tecnativa.com)
* Jairo Llopis <jairo.llopis@tecnativa.com> (https://wwww.tecnativa.com)
